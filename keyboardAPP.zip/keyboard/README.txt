Don't erase the DJ_Keyboard.txt file

and Thanks